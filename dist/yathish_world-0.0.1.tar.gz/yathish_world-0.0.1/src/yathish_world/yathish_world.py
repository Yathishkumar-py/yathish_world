

def yathish_world():
    return 'welcome to yathish\'s world'